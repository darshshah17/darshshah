def optimize_rectangle(x):
    print("This program will print out the optimal area of a rectangle.")
    print("Let's get started!\n")

    dimension = x/4

    if ".0" in str(dimension):
        dimension = int(dimension)

    print("\nThe dimensions to maximize the area will be " + str(dimension) + " x " + str(dimension) + ".")
    print("\nThe maximum area possible is " + str(dimension**2) + " units².")