import math

def optimize_cylinder(sa):
    print("This program will output the dimensions to produce the max area.")

    r = math.sqrt(sa/(6*math.pi))

    h = 2*r

    v = math.pi*(r**2)*h

    print("The radius should be: {} units".format(str(r)))
    print("The height should be: {} units".format(str(h)))

    print("\nThe maximum volume possible is {} units³".format(str(v)))