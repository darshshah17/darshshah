import math
import time
from optimizing_cylinder import optimize_cylinder
from optimizing_rectangle import optimize_rectangle

print("You can pick between a rectangle and cylinder and by inputing just one value, we can tell you the optimal dimensions!")
print("Let's get started!")

choice = input("Would you like to optimize a cylinder or rectangle (C/R): ").upper()

while choice != "R" or choice != "C":
    if choice == "R" or choice == "C":
        break
    print("Please enter either 'C' or 'R'.")
    choice = input("Would you like to optimize a cylinder or rectangle (C/R): ").upper()

if choice == "C":
    sa = int(input("Please enter the surface area of the cylinder: "))
    optimize_cylinder(sa)
else:
    x = int(input("Please enter the perimeter of the rectangle: "))
    optimize_rectangle(x)

time.sleep(10)



